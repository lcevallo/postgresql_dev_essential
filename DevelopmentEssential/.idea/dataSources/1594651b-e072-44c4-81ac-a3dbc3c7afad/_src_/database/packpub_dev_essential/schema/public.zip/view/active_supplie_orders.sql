CREATE VIEW active_supplie_orders AS SELECT suppliers.supplier_id,
    suppliers.supplier_name,
    orders.quanity,
    orders.price
   FROM (suppliers
     JOIN orders ON ((suppliers.supplier_id = orders.supplier_id)))
  WHERE (((suppliers.supplier_name)::text = 'XYZ COMPANY'::text) AND ((orders.is_active)::text = 'TRUE'::text));
